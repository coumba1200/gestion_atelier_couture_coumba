package repositories.list;

import entities.Unite;


public class TableUnites extends Table<Unite> { 
    
}
