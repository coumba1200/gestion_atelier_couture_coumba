package services;
import entities.ArticleConfection;
import repositories.ITables;

import java.util.ArrayList;

public class ArticleConfectionServiceImpl implements ArticleConfectionService {

    private ITables<ArticleConfection> articleRepository;

    public ArticleConfectionServiceImpl(ITables<ArticleConfection> repository) {
        this.articleRepository = repository;
    }

    @Override
    public int add(ArticleConfection article) {
        return articleRepository.insert(article);
    }

    @Override
    public int update(ArticleConfection article) {
        return articleRepository.update(article);
    }

    @Override
    public int remove(int id) {
        return articleRepository.delete(id);
    }

    @Override
    public ArrayList<ArticleConfection> getAll() {
        return articleRepository.findAll();
    }

    @Override
    public ArticleConfection getById(int id) {
        return articleRepository.findById(id);
    }
}
