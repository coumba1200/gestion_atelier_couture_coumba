package services;
import entities.ArticleConfection;
import java.util.ArrayList;

public interface ArticleConfectionService {
    int add(ArticleConfection article);
    int update(ArticleConfection article);
    int remove(int id);
    ArrayList<ArticleConfection> getAll();
    ArticleConfection getById(int id);
}